from gui.visitor_form import VisitorApp


def main() -> None:
    app = VisitorApp()
    app.run()


if __name__ == "__main__":
    main()
