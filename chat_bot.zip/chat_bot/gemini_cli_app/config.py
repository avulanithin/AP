# config.py
# Replace "API_KEY" with your actual Gemini API key from Google AI Studio.
API_KEY = "AIzaSyCbYWESeP5DYNdbLzcHiHIRXuc6ZusOksg"
